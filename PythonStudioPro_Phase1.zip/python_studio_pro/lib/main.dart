import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_code_editor/flutter_code_editor.dart';
import 'package:flutter_highlight/themes/monokai-sublime.dart';
import 'package:highlight/languages/python.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

const _method = MethodChannel('pystudio/run');
const _events = EventChannel('pystudio/out');

class Line {
  final String kind, text;
  Line(this.kind, this.text);
}

class AppState extends ChangeNotifier {
  late Directory dir;
  List<File> files = [];
  File? current;
  final code = CodeController(text: '', language: python);
  final out = <Line>[];
  bool running = false;
  double fontSize = 14;
  Timer? _debounce;

  Future<void> init() async {
    final docs = await getApplicationDocumentsDirectory();
    dir = Directory(p.join(docs.path, 'projects', 'default'))..createSync(recursive: true);
    if (dir.listSync().isEmpty) {
      File(p.join(dir.path, 'main.py')).writeAsStringSync(
          "name = input('Your name? ')\nfor i in range(3):\n    print('Hello,', name, i)\n");
    }
    refresh();
    open(files.first);
    code.addListener(() {
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 600), save);
    });
    _events.receiveBroadcastStream().listen((ev) {
      final m = Map<String, dynamic>.from(ev as Map);
      if (m['kind'] == 'done') running = false;
      out.add(Line(m['kind'] == 'done' ? 'sys' : m['kind'], m['text']));
      notifyListeners();
    });
    try {
      final v = await _method.invokeMethod('info');
      out.add(Line('sys', 'Python ${(v as String).split(' ').first} ready\n'));
    } catch (e) {
      out.add(Line('err', 'Runtime unavailable: $e\n'));
    }
  }

  void refresh() {
    files = dir.listSync().whereType<File>().where((f) => f.path.endsWith('.py')).toList()
      ..sort((a, b) => a.path.compareTo(b.path));
    notifyListeners();
  }

  void open(File f) {
    save();
    current = f;
    code.text = f.readAsStringSync();
    notifyListeners();
  }

  void save() {
    current?.writeAsStringSync(code.text);
  }

  void insert(String t) {
    final sel = code.selection;
    final text = code.text;
    final s = sel.isValid ? sel.start : text.length;
    final e = sel.isValid ? sel.end : s;
    code.text = text.replaceRange(s, e, t);
    code.selection = TextSelection.collapsed(offset: s + t.length);
  }

  Future<void> run() async {
    if (current == null || running) return;
    save();
    out.add(Line('sys', '\n$ python ${p.basename(current!.path)}\n'));
    running = true;
    notifyListeners();
    try {
      await _method.invokeMethod('run', {'path': current!.path, 'cwd': dir.path});
    } catch (e) {
      running = false;
      out.add(Line('err', '$e\n'));
      notifyListeners();
    }
  }

  Future<void> stop() => _method.invokeMethod('stop');

  Future<void> sendInput(String t) async {
    out.add(Line('in', '$t\n'));
    notifyListeners();
    await _method.invokeMethod('input', {'text': t});
  }

  void createFile(String name) {
    if (!name.endsWith('.py')) name += '.py';
    name = p.basename(name); // safe path: no directory traversal
    final f = File(p.join(dir.path, name));
    if (!f.existsSync()) f.writeAsStringSync('print("Hello from $name")\n');
    refresh();
    open(f);
  }

  void deleteFile(File f) {
    f.deleteSync();
    refresh();
    if (current?.path == f.path) {
      if (files.isEmpty) createFile('main.py');
      open(files.first);
    }
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final app = AppState();
  await app.init();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true),
    home: Home(app),
  ));
}

class Home extends StatefulWidget {
  final AppState s;
  const Home(this.s, {super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  AppState get s => widget.s;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: Text(s.current == null ? 'Python Studio Pro' : p.basename(s.current!.path)),
          actions: [
            IconButton(icon: const Icon(Icons.save), onPressed: s.save),
            s.running
                ? IconButton(icon: const Icon(Icons.stop, color: Colors.redAccent), onPressed: s.stop)
                : IconButton(
                    icon: const Icon(Icons.play_arrow, color: Colors.greenAccent),
                    onPressed: () {
                      s.run();
                      setState(() => tab = 1);
                    }),
          ],
        ),
        body: IndexedStack(index: tab, children: [_editor(), _terminal(), _files()]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.code), label: 'Editor'),
            NavigationDestination(icon: Icon(Icons.terminal), label: 'Terminal'),
            NavigationDestination(icon: Icon(Icons.folder), label: 'Files'),
          ],
        ),
      ),
    );
  }

  Widget _editor() {
    const keys = ['    ', '(', ')', '[', ']', '{', '}', ':', '"', "'", '=', '_', '#', '.'];
    return Column(children: [
      Expanded(
        child: CodeTheme(
          data: CodeThemeData(styles: monokaiSublimeTheme),
          child: SingleChildScrollView(
            child: CodeField(
              controller: s.code,
              textStyle: TextStyle(fontFamily: 'monospace', fontSize: s.fontSize),
            ),
          ),
        ),
      ),
      SizedBox(
        height: 44,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final k in keys)
            TextButton(onPressed: () => s.insert(k), child: Text(k.trim().isEmpty ? 'TAB' : k)),
        ]),
      ),
    ]);
  }

  final _scroll = ScrollController();
  final _input = TextEditingController();

  Widget _terminal() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
    Color c(String k) => k == 'err' ? Colors.redAccent : k == 'sys' ? Colors.grey : k == 'in' ? Colors.lightBlueAccent : Colors.white;
    return Column(children: [
      Expanded(
        child: SingleChildScrollView(
          controller: _scroll,
          padding: const EdgeInsets.all(8),
          child: SizedBox(
            width: double.infinity,
            child: SelectableText.rich(TextSpan(children: [
              for (final l in s.out)
                TextSpan(text: l.text, style: TextStyle(color: c(l.kind), fontFamily: 'monospace', fontSize: 13)),
            ])),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _input,
              decoration: const InputDecoration(hintText: 'input() ...', isDense: true, border: OutlineInputBorder()),
              onSubmitted: (t) {
                s.sendInput(t);
                _input.clear();
              },
            ),
          ),
          IconButton(icon: const Icon(Icons.delete_sweep), onPressed: () { s.out.clear(); s.notifyListeners(); }),
        ]),
      ),
    ]);
  }

  Widget _files() {
    return Scaffold(
      body: ListView(children: [
        for (final f in s.files)
          ListTile(
            leading: const Icon(Icons.description),
            title: Text(p.basename(f.path)),
            selected: s.current?.path == f.path,
            onTap: () {
              s.open(f);
              setState(() => tab = 0);
            },
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: Text('Delete ${p.basename(f.path)}?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                      TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
                    ],
                  ),
                );
                if (ok == true) s.deleteFile(f);
              },
            ),
          ),
      ]),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          final c = TextEditingController();
          final name = await showDialog<String>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('New Python file'),
              content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'script.py')),
              actions: [TextButton(onPressed: () => Navigator.pop(context, c.text), child: const Text('Create'))],
            ),
          );
          if (name != null && name.trim().isNotEmpty) {
            s.createFile(name.trim());
            setState(() => tab = 0);
          }
        },
      ),
    );
  }
}
