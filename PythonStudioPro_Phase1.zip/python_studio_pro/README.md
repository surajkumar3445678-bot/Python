# Python Studio Pro - Phase 1

Runtime: CPython 3.12 via Chaquopy 17.0.0 (Gradle files are patched, not replaced). ABIs: arm64-v8a, x86_64. minSdk 24.

## Implemented (NOT yet tested on a device - first build may need small fixes)
- Real Python execution (runpy) in a worker thread, stdout/stderr streamed live
- input() via terminal panel, Stop button (async KeyboardInterrupt)
- Code editor with Python highlighting (flutter_code_editor), symbol row, autosave
- Basic project (one folder): create/open/delete .py files, multi-file imports work

## Not yet done
Turtle/2D canvas, games, package manager, ZIP, AI, 3D, tests, separate-process isolation, timeouts.

## Build
GitHub: push this folder to a repo -> Actions -> "Build APK" -> download artifact.
Local: `bash tools/setup_android.sh && flutter pub get && flutter build apk --debug`
Release: `flutter build apk --release` (debug-signed for now).

## Troubleshooting
- Chaquopy/AGP version mismatch: change the Chaquopy version in tools/setup_android.sh (see chaquo.com compatibility table).
- `python3` not found by Gradle: set buildPython path in native/app.build.gradle.kts.
- Infinite loop `while True: pass` may stop slowly; a real process kill comes in a later phase.

## Logo
Icon files are in native/icons (logo_1024.png + mipmap sizes). tools/setup_android.sh copies them into the Android project and sets the app name.
