import builtins, ctypes, os, runpy, sys, threading, traceback

_tid = None
_sink = None


class _W:
    def __init__(self, kind):
        self.kind = kind

    def write(self, s):
        if s:
            _sink.emit(self.kind, s)
        return len(s) if s else 0

    def flush(self):
        pass


def _input(prompt=""):
    if prompt:
        _sink.emit("out", str(prompt))
    line = _sink.readLine()
    if line is None:
        raise EOFError("input closed")
    return line


def run(path, cwd, sink):
    global _tid, _sink
    _sink = sink
    _tid = threading.get_ident()
    os.chdir(cwd)
    sys.path.insert(0, cwd)
    old = (sys.stdout, sys.stderr, builtins.input)
    sys.stdout, sys.stderr, builtins.input = _W("out"), _W("err"), _input
    sys.argv = [path]
    code = 0
    try:
        runpy.run_path(path, run_name="__main__")
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 0
    except KeyboardInterrupt:
        sys.stderr.write("\nStopped.\n")
        code = -1
    except BaseException:
        sys.stderr.write(traceback.format_exc())
        code = 1
    finally:
        sys.stdout, sys.stderr, builtins.input = old
        if cwd in sys.path:
            sys.path.remove(cwd)
        _tid = None
    return code


def stop():
    if _tid is not None:
        ctypes.pythonapi.PyThreadState_SetAsyncExc(
            ctypes.c_ulong(_tid), ctypes.py_object(KeyboardInterrupt))
