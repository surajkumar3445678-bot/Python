package com.example.pythonstudio

import android.os.Handler
import android.os.Looper
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.LinkedBlockingQueue

class Sink(private val post: (String, String) -> Unit) {
    val queue = LinkedBlockingQueue<String>()
    fun emit(kind: String, text: String) = post(kind, text)
    fun readLine(): String? {
        val s = queue.take()
        return if (s == "\u0000EOF") null else s
    }
}

class MainActivity : FlutterActivity() {
    private var events: EventChannel.EventSink? = null
    private val ui = Handler(Looper.getMainLooper())
    private var sink: Sink? = null
    private var worker: Thread? = null

    private fun send(kind: String, text: String) {
        ui.post { events?.success(mapOf("kind" to kind, "text" to text)) }
    }

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        val bm = engine.dartExecutor.binaryMessenger
        EventChannel(bm, "pystudio/out").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, s: EventChannel.EventSink?) { events = s }
            override fun onCancel(args: Any?) { events = null }
        })
        MethodChannel(bm, "pystudio/run").setMethodCallHandler { call, result ->
            when (call.method) {
                "info" -> result.success(Python.getInstance().getModule("sys").get("version").toString())
                "run" -> {
                    if (worker?.isAlive == true) {
                        result.error("busy", "A program is already running", null)
                        return@setMethodCallHandler
                    }
                    val s = Sink(::send)
                    sink = s
                    val path = call.argument<String>("path")!!
                    val cwd = call.argument<String>("cwd")!!
                    worker = Thread {
                        val code = try {
                            Python.getInstance().getModule("runner").callAttr("run", path, cwd, s).toInt()
                        } catch (e: Throwable) {
                            send("err", "Runtime error: ${e.message}\n"); -2
                        }
                        send("done", "\n[process finished with exit code $code]\n")
                    }.also { it.start() }
                    result.success(null)
                }
                "input" -> {
                    sink?.queue?.put(call.argument<String>("text") ?: "")
                    result.success(null)
                }
                "stop" -> {
                    sink?.queue?.put("\u0000EOF")
                    Thread { Python.getInstance().getModule("runner").callAttr("stop") }.start()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}
