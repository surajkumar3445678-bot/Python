#!/usr/bin/env bash
# Generates android/ with Flutter, then PATCHES (not replaces) the generated Gradle files
# so it stays valid with whatever AGP/Gradle version Flutter currently uses.
set -e
if [ ! -d android ]; then
  mkdir -p /tmp/keep && cp -r lib pubspec.yaml /tmp/keep/
  flutter create --platforms=android --org com.example --project-name python_studio_pro .
  rm -rf lib && cp -r /tmp/keep/lib . && cp /tmp/keep/pubspec.yaml .
fi

# Kotlin bridge: use the generated package (com.example.python_studio_pro)
KDIR=android/app/src/main/kotlin/com/example/python_studio_pro
mkdir -p "$KDIR" android/app/src/main/python
cp native/MainActivity.kt "$KDIR/MainActivity.kt"
sed -i 's/^package .*/package com.example.python_studio_pro/' "$KDIR/MainActivity.kt"
cp native/runner.py android/app/src/main/python/

# Chaquopy plugin in settings.gradle.kts (anchor on the Android app plugin line)
S=android/settings.gradle.kts
if ! grep -q "com.chaquo.python" "$S"; then
  sed -i '/id("com.android.application")/a\    id("com.chaquo.python") version "17.0.0" apply false' "$S"
fi

# Patch app/build.gradle.kts
APP=android/app/build.gradle.kts
if ! grep -q "com.chaquo.python" "$APP"; then
  sed -i '/id("dev.flutter.flutter-gradle-plugin")/a\    id("com.chaquo.python")' "$APP"
  sed -i '/defaultConfig {/a\        ndk { abiFilters.addAll(listOf("arm64-v8a", "x86_64")) }' "$APP"
  cat >> "$APP" <<'EOT'

chaquopy {
    defaultConfig {
        version = "3.12"
        buildPython("python3")
    }
}
EOT
fi

# App icon + name
if [ -d native/icons ]; then
  for d in native/icons/mipmap-*; do
    n=$(basename "$d"); mkdir -p "android/app/src/main/res/$n"
    cp "$d/ic_launcher.png" "android/app/src/main/res/$n/ic_launcher.png"
  done
fi
sed -i 's/android:label="[^"]*"/android:label="Python Studio Pro"/' android/app/src/main/AndroidManifest.xml
echo "Setup done."
echo "--- settings ---"; cat "$S"; echo "--- app build ---"; cat "$APP"
